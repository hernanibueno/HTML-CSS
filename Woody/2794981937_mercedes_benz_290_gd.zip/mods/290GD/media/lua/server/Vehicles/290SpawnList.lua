if VehicleZoneDistribution then

    VehicleZoneDistribution.parkingstall.vehicles["Base.290D2Door"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.parkingstall.vehicles["Base.290D2DoorSmall"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.parkingstall.vehicles["Base.290GD4Door"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.parkingstall.vehicles["Base.290GDOpenTop"] = {index = -1, spawnChance = 2};
    
    VehicleZoneDistribution.good.vehicles["Base.290D2Door"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.good.vehicles["Base.290D2DoorSmall"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.good.vehicles["Base.290GD4Door"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.good.vehicles["Base.290GDOpenTop"] = {index = -1, spawnChance = 2};
        
end
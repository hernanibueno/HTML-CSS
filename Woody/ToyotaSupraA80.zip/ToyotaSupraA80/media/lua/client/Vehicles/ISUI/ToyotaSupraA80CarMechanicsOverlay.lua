local function info()
ISCarMechanicsOverlay.CarList["Base.ToyotaSupraA80"] = {imgPrefix = "ToyotaSupraA80_", x=10,y=0};
--
ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles["ToyotaSupraA80_"] = {x=22,y=394,x2=53,y2=430};
ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles["ToyotaSupraA80_"] = {x=232,y=394,x2=263,y2=430};
ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles["ToyotaSupraA80_"] = {x=90,y=264,x2=99,y2=346};
ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles["ToyotaSupraA80_"] = {x=193,y=264,x2=202,y2=346};
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles["ToyotaSupraA80_"] = {x=21,y=358,x2=59,y2=394};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles["ToyotaSupraA80_"] = {x=231,y=358,x2=264,y2=394};
ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles["ToyotaSupraA80_"] = {x=99,y=284,x2=113,y2=346};
ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles["ToyotaSupraA80_"] = {x=180,y=284,x2=202,y2=346};
ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles["ToyotaSupraA80_"] = {x=102,y=360,x2=189,y2=415};
ISCarMechanicsOverlay.PartList["Windshield"].vehicles["ToyotaSupraA80_"] = {x=110,y=256,x2=182,y2=294};
ISCarMechanicsOverlay.PartList["TruckBed"].vehicles["ToyotaSupraA80_"] = {x=98,y=415,x2=196,y2=438};
end


Events.OnInitWorld.Add(info);
require "Vehicles/TimedActions/ISOpenVehicleDoor"

local old_ISOpenVehicleDoor_start = ISOpenVehicleDoor.start
local old_ISOpenVehicleDoor_perform = ISOpenVehicleDoor.perform

function ISOpenVehicleDoor:perform()
	old_ISOpenVehicleDoor_perform(self)
	Vehicles.Update.Supra_Door(self.vehicle, self.part)
end

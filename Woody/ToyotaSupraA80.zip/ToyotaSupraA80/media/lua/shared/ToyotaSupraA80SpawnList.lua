if VehicleZoneDistribution then

VehicleZoneDistribution.parkingstall.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 1};

VehicleZoneDistribution.trailerpark.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 1};

VehicleZoneDistribution.medium.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 1};

VehicleZoneDistribution.good.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.ranger.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 5};

end
local distributionTable = VehicleDistributions[1]

distributionTable["ToyotaSupraA80"] = distributionTable["CarNormal"]


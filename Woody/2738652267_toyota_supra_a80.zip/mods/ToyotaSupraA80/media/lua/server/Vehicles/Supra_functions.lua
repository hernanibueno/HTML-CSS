require "Vehicles/Vehicles"

function Vehicles.Update.Supra_Door(vehicle, part, elapsedMinutes)

	local invItem = part:getInventoryItem();
	if not invItem then
		return
	end

	if part:getItemType():isEmpty() then
		return false
	end
	if not part:getDoor() then
		return false
	end
	if part:getDoor():isOpen() then
			part:setModelVisible("Default", false)
			part:setModelVisible("Open", true)	 vehicle:doDamageOverlay()
			part:setModelVisible("Default2", false)
			part:setModelVisible("Open2", true)	 vehicle:doDamageOverlay()
			part:setModelVisible("Default3", false)
			part:setModelVisible("Open3", true)
			vehicle:update()
	else
			part:setModelVisible("Default", true)  vehicle:doDamageOverlay()
			part:setModelVisible("Open", false)
			part:setModelVisible("Default2", true)  vehicle:doDamageOverlay()
			part:setModelVisible("Open2", false)
			part:setModelVisible("Default3", true)  vehicle:doDamageOverlay()
			part:setModelVisible("Open3", false)
	end

end

function Vehicles.Init.Supra_Door(vehicle, part)
	Vehicles.Update.Supra_Door(vehicle, part, elapsedMinutes)
end

function Vehicles.Use.Supra_Door(vehicle, part, character)
	Vehicles.Use.Door(vehicle, part, character)
end
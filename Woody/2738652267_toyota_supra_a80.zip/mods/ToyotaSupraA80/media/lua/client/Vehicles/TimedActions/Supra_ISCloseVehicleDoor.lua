require "Vehicles/TimedActions/ISCloseVehicleDoor"

local old_ISCloseVehicleDoor_perform = ISCloseVehicleDoor.perform

function ISCloseVehicleDoor:perform()
	old_ISCloseVehicleDoor_perform(self)
	Vehicles.Update.Supra_Door(self.vehicle, self.part)
end


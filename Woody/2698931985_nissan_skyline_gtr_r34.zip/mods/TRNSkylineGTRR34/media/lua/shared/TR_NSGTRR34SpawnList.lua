if VehicleZoneDistribution then

VehicleZoneDistribution.parkingstall.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.trailerpark.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 0};
VehicleZoneDistribution.bad.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 0};
VehicleZoneDistribution.good.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.junkyard.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 0};
VehicleZoneDistribution.trafficjamw.vehicles["Base.tr_nsgtrr34"] = {index = -1, spawnChance = 1};
end
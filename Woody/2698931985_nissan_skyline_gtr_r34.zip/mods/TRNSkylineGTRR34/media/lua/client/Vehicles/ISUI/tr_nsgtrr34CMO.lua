local function info()
ISCarMechanicsOverlay.CarList["Base.tr_nsgtrr34"] = {imgPrefix = "tr_nskylinegtrr34_", x=10,y=0};
--
ISCarMechanicsOverlay.PartList["Battery"].vehicles = ISCarMechanicsOverlay.PartList["Battery"].vehicles or {};
ISCarMechanicsOverlay.PartList["Battery"].vehicles["tr_nskylinegtrr34_"] = {img="battery", x=183,y=62,x2=226,y2=94};
--
ISCarMechanicsOverlay.PartList["BrakeFrontLeft"] = {img="brakefl", vehicles = {}};
ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=17,y=198,x2=55,y2=233};
ISCarMechanicsOverlay.PartList["BrakeFrontRight"] = {img="brakefr", vehicles = {}};
ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles["tr_nskylinegtrr34_"] = {img="brakefr", x=227,y=198,x2=265,y2=233};
ISCarMechanicsOverlay.PartList["BrakeRearLeft"] = {img="brakerl", vehicles = {}};
ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles["tr_nskylinegtrr34_"] = {x=17,y=401,x2=55,y2=436};
ISCarMechanicsOverlay.PartList["BrakeRearRight"] = {img="brakerr", vehicles = {}};
ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles = ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles["tr_nskylinegtrr34_"] = {x=227,y=401,x2=265,y2=436};
--
ISCarMechanicsOverlay.PartList["DoorFrontLeft"] = {img="doorFL", vehicles = {}};
ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=72,y=243,x2=85,y2=340};
ISCarMechanicsOverlay.PartList["DoorFrontRight"] = {img="doorFR", vehicles = {}};
ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles["tr_nskylinegtrr34_"] = {x=193,y=243,x2=210,y2=340};
--
ISCarMechanicsOverlay.PartList["Engine"].vehicles = ISCarMechanicsOverlay.PartList["Engine"].vehicles or {};
ISCarMechanicsOverlay.PartList["Engine"].vehicles["tr_nskylinegtrr34_"] = {img="engine", x=57,y=34,x2=156,y2=93};
--
ISCarMechanicsOverlay.PartList["EngineDoor"] = {img="enginedoor", vehicles = {}};
ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles = ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles or {};
ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles["tr_nskylinegtrr34_"] = {x=94,y=153,x2=188,y2=224};
--
ISCarMechanicsOverlay.PartList["GasTank"].vehicles = ISCarMechanicsOverlay.PartList["GasTank"].vehicles or {};
ISCarMechanicsOverlay.PartList["GasTank"].vehicles["tr_nskylinegtrr34_"] = {img="gastank", x=144,y=506,x2=230,y2=561};
--
ISCarMechanicsOverlay.PartList["HeadlightLeft"] = {img="headlightLeft", vehicles = {}};
ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles = ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles["tr_nskylinegtrr34_"] = {x=86,y=139,x2=111,y2=153};
ISCarMechanicsOverlay.PartList["HeadlightRight"] = {img="headlightRight", vehicles = {}};
ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles = ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles["tr_nskylinegtrr34_"] = {img="headlightRight", x=171,y=139,x2=196,y2=153};
--
ISCarMechanicsOverlay.PartList["Muffler"].vehicles = ISCarMechanicsOverlay.PartList["Muffler"].vehicles or {};
ISCarMechanicsOverlay.PartList["Muffler"].vehicles["tr_nskylinegtrr34_"] = {img="muffler", x=77,y=507,x2=112,y2=573};
--
ISCarMechanicsOverlay.PartList["SeatFrontLeft"] = {img="seatFL", vehicles = {"tr_nskylinegtrr34_"}};
ISCarMechanicsOverlay.PartList["SeatFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["SeatFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SeatFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=110,y=292,x2=134,y2=317};
ISCarMechanicsOverlay.PartList["SeatFrontRight"] = {img="seatFR", vehicles = {"tr_nskylinegtrr34_"}};
ISCarMechanicsOverlay.PartList["SeatFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["SeatFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SeatFrontRight"].vehicles["tr_nskylinegtrr34_"] = {x=146,y=292,x2=172,y2=317};
--
ISCarMechanicsOverlay.PartList["SeatRearLeft"] = {img="seatRL", vehicles = {"tr_nskylinegtrr34_"}};
ISCarMechanicsOverlay.PartList["SeatRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["SeatRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SeatRearLeft"].vehicles["tr_nskylinegtrr34_"] = {x=109,y=337,x2=134,y2=363};
ISCarMechanicsOverlay.PartList["SeatRearRight"] = {img="seatRR", vehicles = {"tr_nskylinegtrr34_"}};
ISCarMechanicsOverlay.PartList["SeatRearRight"].vehicles = ISCarMechanicsOverlay.PartList["SeatRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SeatRearRight"].vehicles["tr_nskylinegtrr34_"] = {x=146,y=337,x2=172,y2=363};
--
ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"] = {img="suspensionFL", vehicles = {}};
ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=17,y=161,x2=55,y2=197};
ISCarMechanicsOverlay.PartList["SuspensionFrontRight"] = {img="suspensionFR", vehicles = {}};
ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles["tr_nskylinegtrr34_"] = {x=227,y=161,x2=265,y2=197};
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"] = {img="suspensionRL", vehicles = {}};
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles["tr_nskylinegtrr34_"] = {x=17,y=364,x2=55,y2=400};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"] = {img="suspensionRR", vehicles = {}};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles["tr_nskylinegtrr34_"] = {x=227,y=364,x2=265,y2=400};
--
ISCarMechanicsOverlay.PartList["TireFrontLeft"] = {img="WheelFL", vehicles = {}};
ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=69,y=173,x2=75,y2=220};
ISCarMechanicsOverlay.PartList["TireFrontRight"] = {img="WheelFR", vehicles = {}};
ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles["tr_nskylinegtrr34_"] = {x=207,y=173,x2=213,y2=220};
ISCarMechanicsOverlay.PartList["TireRearLeft"] = {img="WheelRL", vehicles = {}};
ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles["tr_nskylinegtrr34_"] = {x=69,y=375,x2=76,y2=421};
ISCarMechanicsOverlay.PartList["TireRearRight"] = {img="WheelRR", vehicles = {}};
ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles = ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles["tr_nskylinegtrr34_"] = {x=206,y=374,x2=214,y2=421};
--
ISCarMechanicsOverlay.PartList["TruckBed"] = {img="trunkdoor", vehicles = {}};
ISCarMechanicsOverlay.PartList["TruckBed"].vehicles = ISCarMechanicsOverlay.PartList["TruckBed"].vehicles or {};
ISCarMechanicsOverlay.PartList["TruckBed"].vehicles["tr_nskylinegtrr34_"] = {img="trunkdoor", x=87,y=416,x2=195,y2=463};
--
ISCarMechanicsOverlay.PartList["WindowFrontLeft"] = {img="windowFL", vehicles = {}};
ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles["tr_nskylinegtrr34_"] = {x=86,y=267,x2=99,y2=332};
ISCarMechanicsOverlay.PartList["WindowFrontRight"] = {img="windowFR", vehicles = {}};
ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles["tr_nskylinegtrr34_"] = {x=183,y=267,x2=196,y2=332};
--
ISCarMechanicsOverlay.PartList["WindowRearLeft"] = {img="windowRL", vehicles = {}};
ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles["tr_nskylinegtrr34_"] = {x=87,y=341,x2=99,y2=367};
ISCarMechanicsOverlay.PartList["WindowRearRight"] = {img="windowRR", vehicles = {}};
ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles = ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles["tr_nskylinegtrr34_"] = {x=183,y=341,x2=195,y2=367};
--
ISCarMechanicsOverlay.PartList["Windshield"] = {img="windshieldFront", vehicles = {}};
ISCarMechanicsOverlay.PartList["Windshield"].vehicles = ISCarMechanicsOverlay.PartList["Windshield"].vehicles or {};
ISCarMechanicsOverlay.PartList["Windshield"].vehicles["tr_nskylinegtrr34_"] = {img="windshieldFront", x=92,y=228,x2=190,y2=279};
--
ISCarMechanicsOverlay.PartList["WindshieldRear"] = {img="windshieldRear", vehicles = {}};
ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles = ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles["tr_nskylinegtrr34_"] = {x=97,y=372,x2=184,y2=426};
end
Events.OnInitWorld.Add(info);
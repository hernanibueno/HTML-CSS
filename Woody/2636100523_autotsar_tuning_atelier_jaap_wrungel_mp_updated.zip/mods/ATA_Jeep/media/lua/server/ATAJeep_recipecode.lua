function Recipe.OnCreate.CutATAJeepBumper4Item(items, result, player)
    player:getInventory():AddItem("Base.MetalPipe");
    player:getInventory():AddItem("Base.MetalPipe");
    player:getInventory():AddItem("Base.MetalBar");
    player:getInventory():AddItem("Base.UnusableMetal");
    player:getInventory():AddItem("Base.UnusableMetal");
end
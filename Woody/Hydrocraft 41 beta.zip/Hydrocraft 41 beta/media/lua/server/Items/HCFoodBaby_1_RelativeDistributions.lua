---------------------------------------------------------
--- 2021-12-27 by lorgalis
---------------------------------------------------------
function HCbabyfood(m)
        retVal =
        {
                "Hydrocraft.HCBabyfoodapplesauce",  m*1,
                "Hydrocraft.HCBabyfoodapricots",    m*1,
                "Hydrocraft.HCBabyfoodbananas",     m*1,
                "Hydrocraft.HCBabyfoodbeef",        m*1,
                "Hydrocraft.HCBabyfoodcarrot",      m*10,
                "Hydrocraft.HCBabyfoodchicken",     m*1,
                "Hydrocraft.HCBabyfoodcreamcorn",   m*1,
                "Hydrocraft.HCBabyfoodgreenbeans",  m*1,
                "Hydrocraft.HCBabyfoodlamb",        m*1,
                "Hydrocraft.HCBabyfoodpeach",       m*1,
                "Hydrocraft.HCBabyfoodpear",        m*1,
                "Hydrocraft.HCBabyfoodplums",       m*1,
                "Hydrocraft.HCBabyfoodsquash",      m*1,
                "Hydrocraft.HCBabyfoodsweerpotato", m*1,
                "Hydrocraft.HCBabyfoodturkey",      m*1,
        };
        return retVal
end

function HCbabyfoodtrash(m)
        retVal =
        {
                "Hydrocraft.HCBabyfoodjar",         m*1,
        };
        return retVal
end

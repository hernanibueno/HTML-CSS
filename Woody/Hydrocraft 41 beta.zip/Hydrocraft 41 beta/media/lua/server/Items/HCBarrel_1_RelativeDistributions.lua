---------------------------------------------------------
--- Dead Animals that could be found in butchershops  
--- 2021-12-13 by lorgalis
---------------------------------------------------------
function barrels(m)
        retVal =
        {
                "Hydrocraft.HCBarrelblueempty",         m*1,
        };
        return retVal
end




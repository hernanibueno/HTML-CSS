---------------------------------------------------------
--- 2021-12-26 by lorgalis
--- not items: 
--- HCPushbroom
--- HCBroom
---------------------------------------------------------

function HCsoaps(m)
        retVal =
        {
                "Hydrocraft.HCAmmonia",         m*1,
                "Hydrocraft.HCCleanerall",      m*1,
                "Hydrocraft.HCCleanerfabric",   m*1,
                "Hydrocraft.HCCleanser",        m*1,
                "Hydrocraft.HCFabricsoftener",  m*1,
                "Hydrocraft.HCWindowcleaner",   m*1,
        };
        return retVal
end

function HCcleaning(m)
        retVal =
        {
                "Hydrocraft.HCDustpan",        m*1,
                "Hydrocraft.HCFeatherduster",   m*1,
                "Hydrocraft.HCMothballsbox",    m*1,
                "Hydrocraft.HCWashboard",       m*1,
        };
        return retVal
end

function HCmothball(m)
        retVal =
        {
                "Hydrocraft.HCMothballs",       m*1,
                "Hydrocraft.HCMothballs",       m*1,
                "Hydrocraft.HCMothballs",       m*1,
        };
        return retVal
end


function HCvacs(m)
        retVal =
        {
                "Hydrocraft.HCHandvac",   m*1,
                "Hydrocraft.HCVac",       m*1,
                "Hydrocraft.HCVacuum",    m*1,
                "Hydrocraft.HCShopvac",   m*1,
        };
        return retVal
end



---------------------------------------------------------
--- All Loot Boxes with there relative distributions -
--- 2021-11-17 by lorgalis
---------------------------------------------------------
function lootboxes(m)
        retVal =
        {
                "Hydrocraft.HCBoxelectronic",         m*2,
                "Hydrocraft.HCBoxlab",                m*1,
                "Hydrocraft.HCBoxphoto",              m*5,
                "Hydrocraft.HCBoxgarden",             m*1,
                "Hydrocraft.HCBoxpet",                m*3,
                "Hydrocraft.HCBoxart",                m*1,
                "Hydrocraft.HCBoxholiday",            m*5,
                "Hydrocraft.HCBoxoffice",             m*3,
                "Hydrocraft.HCBoxtoy",                m*1,
        };
        return retVal
end





------------------------------------------------------------ 
-- Adds relative distributions to the  different locations
-- 2021-12-22 by fetisch
------------------------------------------------------------

require "Items/ProceduralDistributions";

require "HCDistributionFunctions";

-- insertItemListsInProcDistribution( "CarSupplyTools",        {                              barrels(1), } );
insertItemListsInProcDistribution( "CrateTools",            {                              barrels(1), } );
insertItemListsInProcDistribution( "GarageTools",           {                              barrels(1), } );
insertItemListsInProcDistribution( "CrateMetalwork",        {                              barrels(1), } );
insertItemListsInProcDistribution( "FactoryLockers",        {                              barrels(0.1), } );
insertItemListsInProcDistribution( "GarageTools",           {                              barrels(0.1), } );
insertItemListsInProcDistribution( "CrateMetalwork",        {                              barrels(0.1), } );

---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function HCcookbooks(m)
        retVal =
        {
                "Hydrocraft.HCBookbaking",          m*1,
                "Hydrocraft.HCBookcheesemaking",    m*1,
                "Hydrocraft.HCBooksausagemaking",   m*1,
                "Hydrocraft.HCBookwinemaking",      m*1,
                "Hydrocraft.HCCookbookalcoholic",   m*1,
                "Hydrocraft.HCCookbookbbq",         m*1,
                "Hydrocraft.HCCookbookbutcher",     m*1,
                "Hydrocraft.HCCookbookdried",       m*1,
                "Hydrocraft.HCCookbookegg",         m*1,
                "Hydrocraft.HCCookbookjerky",       m*1,
                "Hydrocraft.HCCookbookmexican",     m*1,
                "Hydrocraft.HCCookbookpasta",       m*1,
                "Hydrocraft.HCCookbookpickling",    m*1,
                "Hydrocraft.HCCookbookpizza",       m*1,
                "Hydrocraft.HCCookbooksalt",        m*1,
                "Hydrocraft.HCCookbooksmoking",     m*1,
                "Hydrocraft.HCCookbookspices",      m*1,
                "Hydrocraft.HCCookbookyogurt",      m*1,
        };
        return retVal
end

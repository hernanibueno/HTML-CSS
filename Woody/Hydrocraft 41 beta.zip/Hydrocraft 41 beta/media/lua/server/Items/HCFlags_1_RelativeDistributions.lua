---------------------------------------------------------
--- 2021-12-27 by lorgalis
---------------------------------------------------------
function HCflags(m)
        retVal =
        {
                "Hydrocraft.HCFlagamerican",    m*2,
                "Hydrocraft.HCFlaganarchist",   m*5,
                "Hydrocraft.HCFlagbritish",     m*1,
                "Hydrocraft.HCFlagcanadian",    m*1,
                "Hydrocraft.HCFlagczech",       m*1,
                "Hydrocraft.HCFlagdutch",       m*1,
                "Hydrocraft.HCFlagfrench",      m*1,
                "Hydrocraft.HCFlaggerman",      m*1,
                "Hydrocraft.HCFlagitalian",     m*1,
                "Hydrocraft.HCFlagmexican",     m*1,
                "Hydrocraft.HCFlagnewmexico",   m*1,
                "Hydrocraft.HCFlagnorthkorea",  m*1,
                "Hydrocraft.HCFlagsoviet",      m*1,
        };
        return retVal
end

function HCflagsAmerican(m)
        retVal =
        {
                "Hydrocraft.HCFlagamerican",    m*1,
        };
        return retVal
end

function HCflagsAnarchist(m)
        retVal =
        {
                "Hydrocraft.HCFlaganarchist",   m*1,
        };
        return retVal
end
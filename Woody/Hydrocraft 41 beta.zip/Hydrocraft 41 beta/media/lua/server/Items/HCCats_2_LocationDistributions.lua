------------------------------------------------------------ 
-- Adds relative distributions to the  different locations
-- created 2021-12-27 by fetisch
-- @todo - SuburbsDistributions (HCAnimalcage)
------------------------------------------------------------

require "Items/ProceduralDistributions";

require "HCDistributionFunctions";

-- insertItemListsInProcDistribution( "HCAnimalcage",    		{ cats(1) } );



---------------------------------------------------------
--- Dead Animals that could be found in butchershops  
--- 2021-12-13 by lorgalis
---------------------------------------------------------
function telescope(m)
        retVal =
        {
                "Hydrocraft.HCTelescopescope",     m*0.5,
                "Hydrocraft.HCTelescopetripod",    m*0.5,
                "Hydrocraft.HCTelescopebox",       m*1,
        };
        return retVal
end




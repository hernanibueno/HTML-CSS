------------------------------------------------------------ 
-- Adds relative distributions to the  different locations
-- created 2021-12-30 by fetisch
------------------------------------------------------------

require "Items/ProceduralDistributions";

require "HCDistributionFunctions";

-- insertItemListsInProcDistribution( "WhiskeyBottlingFull",    	{ HCbreakfast(1),                                                     } );
insertItemListsInProcDistribution( "GigamartDryGoods",    	{ HCbreakfast(1),                                                     } );
insertItemListsInProcDistribution( "KitchenBreakfast",    	{ HCbreakfast(1),                                                     } );
insertItemListsInProcDistribution( "CrateCereal",    		{ HCbreakfast(1),                                                     } );
insertItemListsInProcDistribution( "KitchenDryFood",    	{ HCbreakfast(1),                                                     } );






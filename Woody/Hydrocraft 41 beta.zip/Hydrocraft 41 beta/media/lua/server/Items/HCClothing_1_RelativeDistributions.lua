---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function HChazmat(m)
        retVal =
        {
                "Hydrocraft.HCHazmat",        m*1,
        };
        return retVal
end
function HCgasmask(m)
        retVal =
        {
                "Hydrocraft.HCGasmask",      m*1,
        };
        return retVal
end
function HCprotection(m)
        retVal =
        {
                "Hydrocraft.HCGoogles",       m*1,
                "Hydrocraft.HCRubberglove",   m*1,
        };
        return retVal
end

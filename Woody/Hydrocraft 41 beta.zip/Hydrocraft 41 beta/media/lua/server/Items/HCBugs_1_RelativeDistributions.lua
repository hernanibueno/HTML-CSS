---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function bugs(m)
        retVal =
        {
                "Hydrocraft.HCHousefly",        m*1,
                "Hydrocraft.HCMaggot",          m*1,
                "Base.Cockroach",               m*1,
                "Base.Worm",                    m*1,
        };
        return retVal
end

function spider(m)
        retVal =
        {
                "Hydrocraft.HCHousespider",     m*1,
        };
        return retVal
end

---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function HCcampingitems(m)
        retVal =
        {
                "Hydrocraft.HCMagnesiumstriker",          m*1,
                "Hydrocraft.HCPurifyingtablets",          m*1,
                "Hydrocraft.HCPurifyingtabletsbox",       m*1,
                "Hydrocraft.HCSpaceblanket",              m*1,
        };
        return retVal
end

function HCcampingtools(m)
        retVal =
        {
                "Hydrocraft.HCBinoculars",                m*1,
                "Hydrocraft.HCCanteen",                   m*1,		
                "Hydrocraft.HCJackknife",                 m*1,
		};
        return retVal
end

function HCpaddles(m)
        retVal =
        {
                "Hydrocraft.HCPaddlewood",               m*1,
                "Hydrocraft.HCPaddlemetal",              m*1,
		};
        return retVal
end


function HCcompass(m)
        retVal =
        {
                "Hydrocraft.HCCompass",                   m*0,
                "Hydrocraft.HCGPS",                       m*0,
                "Hydrocraft.HCMap",                       m*0,
        };
        return retVal
end




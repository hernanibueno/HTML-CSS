

--Find seeds in food.
function HCFindSeeds(items, result, player)

local skill = player:getPerkLevel(Perks.PlantScavenging);
local luck = ZombRand(13) + skill;
if  player:getTraits():contains('Lucky') then luck = luck + 5;
end

if luck >= 15 then -- find something

player:Say ('I found seeds');

-- get type of item that was used and add possible results
for i=0, items:size()-1 do
    print (items:get(i):getType())
    if (items:get(i):getType() == "Cereal") then seeds= {'Hydrocraft.HCWheat','Hydrocraft.HCFlaxseeds'};
    elseif (items:get(i):getType() == "Popcorn") then seeds={'Hydrocraft.HCCornseeds','Hydrocraft.HCCornredseeds','Hydrocraft.HCCornblueseeds'};
    elseif (items:get(i):getType() == "HCHerbs") then seeds={'Hydrocraft.HCBasilseeds','Hydrocraft.HCOrangeseeds'};
end 
end 


local count = 0;
local ItemNr = 0;

for _ in pairs(seeds) do count = count + 1 end
ItemNr = ZombRand(count)+1;
player:getInventory():AddItem(seeds[ItemNr]);


else player:Say ('Nothing..');
end -- i was lucky
end -- function





--Randomized Seeds.
function HCRandomseeds(items, result, player)
    local seed = ZombRand(88);	
    if seed == 87 then
        player:getInventory():AddItem("Hydrocraft.HCOreganoseedspacket");  
    elseif seed == 86 then
		player:getInventory():AddItem("Hydrocraft.HCWheatseedpacket");	
    elseif seed == 85 then
		player:getInventory():AddItem("Hydrocraft.HCLimeseedspacket");	
    elseif seed == 84 then	
		player:getInventory():AddItem("Hydrocraft.HCGrapesgreenseedspacket");	
    elseif seed == 83 then
		player:getInventory():AddItem("Hydrocraft.HCDateseedspacket");	
    elseif seed == 82 then
		player:getInventory():AddItem("Hydrocraft.HCFigseedspacket");	
    elseif seed == 81 then
		player:getInventory():AddItem("Hydrocraft.HCKiwiseedspacket");	
    elseif seed == 80 then
		player:getInventory():AddItem("Hydrocraft.HCPlumseedspacket");	
    elseif seed == 79 then
		player:getInventory():AddItem("Hydrocraft.HCPersimmonseedspacket");	
    elseif seed == 78 then
		player:getInventory():AddItem("Hydrocraft.HCCauliflowerseedspacket");	
    elseif seed == 77 then
		player:getInventory():AddItem("Hydrocraft.HCJalapenoseedspacket");	
    elseif seed == 76 then
		player:getInventory():AddItem("Hydrocraft.HCSquashsummerseedspacket");	
    elseif seed == 75 then
		player:getInventory():AddItem("Hydrocraft.HCTomatocherryseedspacket");	
    elseif seed == 74 then	
		player:getInventory():AddItem("Hydrocraft.HCMulberryseedspacket");	
    elseif seed == 73 then		
		player:getInventory():AddItem("Hydrocraft.HCSpinachseedspacket");	
    elseif seed == 72 then	
		player:getInventory():AddItem("Hydrocraft.HCCeleryseedspacket");	
    elseif seed == 71 then		
		player:getInventory():AddItem("Hydrocraft.HCBasilseedspacket");	
    elseif seed == 70 then	
		player:getInventory():AddItem("Hydrocraft.HCAsparagusseedspacket");	
    elseif seed == 69 then	
		player:getInventory():AddItem("Hydrocraft.HCArtichokesseedspacket");	
    elseif seed == 68 then	
		player:getInventory():AddItem("Hydrocraft.HCAlfalfaseedspacket");	
    elseif seed == 67 then	
		player:getInventory():AddItem("Hydrocraft.HCBambooseedspacket");	
    elseif seed == 66 then		
		player:getInventory():AddItem("Hydrocraft.HCJuteseedspacket");	
    elseif seed == 65 then			
		player:getInventory():AddItem("Hydrocraft.HCSpirulinaseedspacket");	
    elseif seed == 64 then		
		player:getInventory():AddItem("Hydrocraft.HCRubbertreeseedspacket");	
    elseif seed == 63 then		
		player:getInventory():AddItem("Hydrocraft.HCRiceseedspacket");	
    elseif seed == 62 then	
		player:getInventory():AddItem("Hydrocraft.HCGingerseedspacket");	
    elseif seed == 61 then	
		player:getInventory():AddItem("Hydrocraft.HCTomatilloseedspacket");	
    elseif seed == 60 then	
		player:getInventory():AddItem("Hydrocraft.HCChiligreenseedspacket");	
    elseif seed == 59 then
		player:getInventory():AddItem("Hydrocraft.HCPricklypearseedspacket");	
    elseif seed == 58 then
		player:getInventory():AddItem("Hydrocraft.HCAgaveblueseedspacket");	
    elseif seed == 57 then
		player:getInventory():AddItem("Hydrocraft.HCCactusseedspacket");	
    elseif seed == 56 then
	    player:getInventory():AddItem("Hydrocraft.HCHempseedspacket");	
    elseif seed == 55 then
	    player:getInventory():AddItem("Hydrocraft.HCPoppyseedspack");		
    elseif seed == 54 then		
	    player:getInventory():AddItem("Hydrocraft.HCChilipepperseedspacket");	
    elseif seed == 53 then	
		player:getInventory():AddItem("Hydrocraft.HCTobaccoseedspacket");
    elseif seed == 52 then
	    player:getInventory():AddItem("farming.CabbageBagSeed");
    elseif seed == 51 then
	    player:getInventory():AddItem("farming.PotatoBagSeed");
    elseif seed == 50 then	
	    player:getInventory():AddItem("farming.TomatoBagSeed");
    elseif seed == 49 then
	    player:getInventory():AddItem("farming.StrewberrieBagSeed");
    elseif seed == 48 then
	    player:getInventory():AddItem("farming.RedRadishBagSeed");
    elseif seed == 47 then
	    player:getInventory():AddItem("farming.BroccoliBagSeed");
    elseif seed == 46 then
	    player:getInventory():AddItem("farming.CarrotBagSeed");
    elseif seed == 45 then
	    player:getInventory():AddItem("Hydrocraft.HCPotatogoldenseedspacket");
    elseif seed == 44 then
	    player:getInventory():AddItem("Hydrocraft.HCPotatoredseedspacket");
    elseif seed == 43 then
	    player:getInventory():AddItem("Hydrocraft.HCCabbagewhiteseedspacket");
    elseif seed == 42 then
	    player:getInventory():AddItem("Hydrocraft.HCCabbageredseedspacket");
    elseif seed == 41 then
	    player:getInventory():AddItem("Hydrocraft.HCCottonseedspacket");
    elseif seed == 40 then
	    player:getInventory():AddItem("Hydrocraft.HCColewortseedspacket");
    elseif seed == 39 then
	    player:getInventory():AddItem("Hydrocraft.HCApricotseedspacket");
    elseif seed == 38 then
	    player:getInventory():AddItem("Hydrocraft.HCCornblueseedspacket");
    elseif seed == 37 then
	    player:getInventory():AddItem("Hydrocraft.HCCornredseedspacket");
    elseif seed == 36 then
	    player:getInventory():AddItem("Hydrocraft.HCCornwhiteseedspacket");
    elseif seed == 35 then
	    player:getInventory():AddItem("Hydrocraft.HCPumpkinbuskinseedspacket");
    elseif seed == 34 then
	    player:getInventory():AddItem("Hydrocraft.HCPumpkingreenseedspacket");
    elseif seed == 33 then
	    player:getInventory():AddItem("Hydrocraft.HCPumpkinwhiteseedspacket");
    elseif seed == 32 then
	    player:getInventory():AddItem("Hydrocraft.HCPumpkinlargeseedspacket");
    elseif seed == 31 then
	    player:getInventory():AddItem("Hydrocraft.HCPotatosweetseedspacket");
    elseif seed == 30 then
	    player:getInventory():AddItem("Hydrocraft.HCOniongreenseedspacket");
    elseif seed == 29 then
	    player:getInventory():AddItem("Hydrocraft.HCGarlicseedspacket");
    elseif seed == 28 then
	    player:getInventory():AddItem("Hydrocraft.HCCucumberseedspacket");
    elseif seed == 27 then
        player:getInventory():AddItem("Hydrocraft.HCChinesecabbageseedspacket");
    elseif seed == 26 then
        player:getInventory():AddItem("Hydrocraft.HCZucchiniseedspacket");
    elseif seed == 25 then
        player:getInventory():AddItem("Hydrocraft.HCPineappleseedspacket");
    elseif seed == 24 then
        player:getInventory():AddItem("Hydrocraft.HCCherryseedspacket");
    elseif seed == 23 then
        player:getInventory():AddItem("Hydrocraft.HCPearseedspacket");
    elseif seed == 22 then
        player:getInventory():AddItem("Hydrocraft.HCAvacadoseedspacket");
    elseif seed == 21 then
        player:getInventory():AddItem("Hydrocraft.HCPeanutseedspacket");
    elseif seed == 20 then
        player:getInventory():AddItem("Hydrocraft.HCPeaseedspacket");
    elseif seed == 19 then
        player:getInventory():AddItem("Hydrocraft.HCOnionseedspacket");
    elseif seed == 18 then
        player:getInventory():AddItem("Hydrocraft.HCLettuceseedspacket");
    elseif seed == 17 then
        player:getInventory():AddItem("Hydrocraft.HCLeekseedspacket");
    elseif seed == 16 then
       player:getInventory():AddItem("Hydrocraft.HCEggplantseedspacket");
    elseif seed == 15 then
        player:getInventory():AddItem("Hydrocraft.HCCornseedspacket");
    elseif seed == 14 then
        player:getInventory():AddItem("Hydrocraft.HCBellpepperyellowseedspacket");
    elseif seed == 13 then
        player:getInventory():AddItem("Hydrocraft.HCBellpepperredseedspacket");
    elseif seed == 12 then
        player:getInventory():AddItem("Hydrocraft.HCBellpeppergreenseedspacket");
    elseif seed == 11 then
        player:getInventory():AddItem("Hydrocraft.HCWatermelonseedspacket");
    elseif seed == 10 then
        player:getInventory():AddItem("Hydrocraft.HCPeachseedspacket");
    elseif seed == 9 then
        player:getInventory():AddItem("Hydrocraft.HCOrangeseedspacket");
    elseif seed == 8 then
        player:getInventory():AddItem("Hydrocraft.HCLemonseedspacket");
    elseif seed == 7 then
        player:getInventory():AddItem("Hydrocraft.HCGrapeseedspacket");
    elseif seed == 6 then
        player:getInventory():AddItem("Hydrocraft.HCBlueberryseedspacket");
    elseif seed == 5 then
        player:getInventory():AddItem("Hydrocraft.HCBlackberryseedspacket");
    elseif seed == 4 then
        player:getInventory():AddItem("Hydrocraft.HCBananaseedspacket");
    elseif seed == 3 then
       player:getInventory():AddItem("Hydrocraft.HCAppleseedspacket");
    elseif seed == 2 then
        player:getInventory():AddItem("Hydrocraft.HCTeaseedspacket");
    elseif seed == 1 then
       player:getInventory():AddItem("Hydrocraft.HCPumpkinseedspacket");   
    elseif seed == 0 then
       player:getInventory():AddItem("Hydrocraft.HCBeanseedspacket");      
    end
end

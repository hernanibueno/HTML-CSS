Hydrocraft Mod for Project Zomboid

Build 41 Beta

!! This build is still considered incomplete/unstable. There "should" not be game breaking updates but heavy changes to Loot Spawn or the general frequency of updates, it could still happen that your game might break or needs to be restarted. !!

This build is intended for those who wish to test and play Hydrocraft until it is considered stable enough to be released to the public. Use at your own risk.

Please do not hesitate to report any issues right here on GitHub.

There are known issues so if you have an example for something that already exist, just add to the issue that is already in the Issues page.
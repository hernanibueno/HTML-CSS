local distributionTable = VehicleDistributions[1]

distributionTable["tr_nsgtrr34"] = distributionTable["SportsCar"]
distributionTable["tr_nsgtrr34ff"] = distributionTable["SportsCar"]
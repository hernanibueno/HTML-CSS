-- Code made by MrDanny - Used as "Template" for my mod, but he has all the credit for this file.
local print = print
local getPlayer = getPlayer
local Say = Say
local ZombRand = ZombRand
local addVehicleDebug = addVehicleDebug
local tostring = tostring
local SandboxVars = SandboxVars
local setFallOnFront = setFallOnFront
local AddWorldInventoryItem = AddWorldInventoryItem
local getCell = getCell
local getGridSquare = getGridSquare
local createRandomDeadBody = createRandomDeadBody
local table = table
local format = string.format -- NOTE: we need this
local ipairs = ipairs
local getActivatedMods = getActivatedMods
local size = size
local get = get
local Dir = IsoDirections -- NOTE: dont pull every direction into local space, just the enum will do.

    
local DEBUG_MSG = false
local MAX_RAND = 100 -- this is used to dictate the odds of all of the vehicles spawning; the higher the number, the less chance they spawn

local SpawnTable = { }

-- NOTE: function adding spawns, instead of nasty manual table inserts
-- this way we can define default values
local function addSpecialSpawn(data)
    data.skin = data.skin or nil
    data.z = data.z or 0
    data.chance = data.chance or 100
    data.always = data.always or false
    
    -- instead of a list table, use a dict table. build the key off the string x,y,z position
    -- theres a number of ways of generating this string, in real lua this is fastest (kahlua needs confirmation) 
    local key = format("%i,%i,%i", data.x, data.y, data.z)
    SpawnTable[key] = data
end

-- basic function redundancy.
local function debugSay(text)
    if not DEBUG_MSG then return end
    print("DEBUG: ".. text)
    getPlayer():Say(text, 1.0, 1.0, 0.0, UIFont.Dialogue, 30.0, "radio")
    
end
 
 
local function checkSpawn(square)
    if not square then return end
    if square:getModData().spawnVehicle then return end
    square:getModData().spawnVehicle = true
    local x, y, z = square:getX(), square:getY(), square:getZ()
    -- NOTE: build the key, and check the table, no need to itterate, or store mod data in the square 
    local key = format("%i,%i,%i", x, y, z)
    local spawn = SpawnTable[key]
    if not spawn then return end

    local roll = ZombRand(0, MAX_RAND)
    local chance = spawn.chance


    debugSay(format("Check Spawn (type: %s), roll vs chance: %s vs %s (always: %s)", spawn.type or "nil", roll, spawn.chance, tostring(spawn.always)))
    
    -- NOTE: reversed the check logic. why? its just cleaner. saves a indentation level
    if roll > chance and (not spawn.always or not ALWAYS_OVERRIDE) then 
        SpawnTable[key] = nil
        return
    end
    debugSay("Roll passed, attempting spawn..")



        --local car = addVehicleDebug(spawn.type, spawn.dir, nil, getCell():getGridSquare(x, y, 0))
        local car = addVehicleDebug(spawn.type, spawn.dir, spawn.skin, square)

   
    SpawnTable[key] = nil
end



Events.LoadGridsquare.Add(checkSpawn) -- every time a grid square is loaded, checks for any vehicle spawn list entries

-- These are an example of table entries that use the Always flag to always spawn
addSpecialSpawn({type = "tr_nsgtrr34ff", x = 3649, y = 8579, dir = Dir.W, chance = 100, always = true})

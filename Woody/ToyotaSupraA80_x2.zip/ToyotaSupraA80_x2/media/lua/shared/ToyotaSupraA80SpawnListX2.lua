if VehicleZoneDistribution then

VehicleZoneDistribution.parkingstall.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 10};

VehicleZoneDistribution.trailerpark.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 10};

VehicleZoneDistribution.medium.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 10};

VehicleZoneDistribution.good.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 10};

VehicleZoneDistribution.ranger.vehicles["Base.ToyotaSupraA80"] = {index = -1, spawnChance = 10};

end
ISCarMechanicsOverlay.PartList["BrakeMiddleLeft"] = {img="brake_middle_left", x=48,y=64,x2=92,y2=99, vehicles={}};
ISCarMechanicsOverlay.PartList["BrakeMiddleRight"] = {img="brake_middle_right", x=48,y=64,x2=92,y2=99, vehicles={}};

ISCarMechanicsOverlay.PartList["SuspensionMiddleLeft"] = {img="suspension_middle_left", x=48,y=64,x2=92,y2=99, vehicles={}};
ISCarMechanicsOverlay.PartList["SuspensionMiddleRight"] = {img="suspension_middle_right", x=48,y=64,x2=92,y2=99, vehicles={}};

ISCarMechanicsOverlay.PartList["TireMiddleLeft"] = {img="wheel_middle_left", x=48,y=64,x2=92,y2=99, vehicles={}};
ISCarMechanicsOverlay.PartList["TireMiddleRight"] = {img="wheel_middle_right", x=48,y=64,x2=92,y2=99, vehicles={}};

-- ISCarMechanicsOverlay.PartList["BrakeMiddleLeft"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
-- ISCarMechanicsOverlay.PartList["BrakeMiddleRight"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
-- ISCarMechanicsOverlay.PartList["SuspensionMiddleLeft"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
-- ISCarMechanicsOverlay.PartList["SuspensionMiddleRight"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
-- ISCarMechanicsOverlay.PartList["TireMiddleLeft"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
-- ISCarMechanicsOverlay.PartList["TireMiddleRight"].vehicles["test_"] = {x=86,y=260,x2=94,y2=342};
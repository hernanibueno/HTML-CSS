return {
	["ShowWorldMap"] = true,
	["WorldShowNames"] = true,
	["WorldShowHeight"] = true,
	["WorldDotColor"] = {
		["r"] = 0.5,
		["g"] = 1,
		["b"] = 0,
		["a"] = 1,
	},
	["ShowMiniMap"] = true,
	["MiniShowNames"] = true,
	["MiniShowHeight"] = true,
	["MiniDotColor"] = {
		["r"] = 0.5,
		["g"] = 1,
		["b"] = 0,
		["a"] = 1,
	},
}
return {
	["AllowWorldMap"] = true,
	["WorldAllowNames"] = true,
	["WorldAllowHeight"] = true,
	["WorldMaximumDistance"] = -1,
	["AllowMiniMap"] = true,
	["MiniAllowNames"] = true,
	["MiniAllowHeight"] = true,
	["MiniMaximumDistance"] = -1,
	["OnlyShowFaction"] = false,
	["AdminsSeeAll"] = true,
}
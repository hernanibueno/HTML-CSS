local function info()
--this chunk here is hell, i hate it so much, gas tank is a piece of...

ISCarMechanicsOverlay.CarList["Base.82oshkoshM911B"] = {imgPrefix = "82oshkoshM911B_", x=10,y=0};
--
ISCarMechanicsOverlay.PartList["Battery"].vehicles = ISCarMechanicsOverlay.PartList["Battery"].vehicles or {};
ISCarMechanicsOverlay.PartList["Battery"].vehicles["82oshkoshM911B_"] = {img="battery", x=14,y=298,x2=58,y2=331};
--
ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionFrontLeft"].vehicles["82oshkoshM911B_"] = {img="suspension_front_left", x=14,y=132,x2=55,y2=170};
ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionFrontRight"].vehicles["82oshkoshM911B_"] = {img="suspension_front_right", x=228,y=132,x2=268,y2=170};
--
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionRearLeft"].vehicles["82oshkoshM911B_"] = {x=14,y=412,x2=55,y2=450};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles = ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["SuspensionRearRight"].vehicles["82oshkoshM911B_"] = {x=228,y=483,x2=268,y2=520};
--
ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeFrontLeft"].vehicles["82oshkoshM911B_"] = {img="brake_front_left", x=14,y=170,x2=55,y2=208};
ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeFrontRight"].vehicles["82oshkoshM911B_"] = {img="brake_front_right", x=228,y=170,x2=268,y2=208};
--
ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeRearLeft"].vehicles["82oshkoshM911B_"] = {x=14,y=450,x2=55,y2=488};
ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles = ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["BrakeRearRight"].vehicles["82oshkoshM911B_"] = {x=228,y=520,x2=268,y2=560};
--
ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["DoorFrontLeft"].vehicles["82oshkoshM911B_"] = {x=0,y=0,x2=0,y2=0};
ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["DoorFrontRight"].vehicles["82oshkoshM911B_"] = {x=0,y=0,x2=0,y2=0};
--
ISCarMechanicsOverlay.PartList["Engine"].vehicles = ISCarMechanicsOverlay.PartList["Engine"].vehicles or {};
ISCarMechanicsOverlay.PartList["Engine"].vehicles["82oshkoshM911B_"] = {x=14,y=34,x2=115,y2=96};
--
ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles = ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["HeadlightLeft"].vehicles["82oshkoshM911B_"] = {x=93,y=115,x2=107,y2=127};
ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles = ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["HeadlightRight"].vehicles["82oshkoshM911B_"] = {x=176,y=115,x2=189,y2=127};
--
ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles = ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles or {};
ISCarMechanicsOverlay.PartList["EngineDoor"].vehicles["82oshkoshM911B_"] = {x=107,y=132,x2=175,y2=208};
--
ISCarMechanicsOverlay.PartList["Muffler"].vehicles = ISCarMechanicsOverlay.PartList["Muffler"].vehicles or {};
ISCarMechanicsOverlay.PartList["Muffler"].vehicles["82oshkoshM911B_"] = {x=232,y=265,x2=268,y2=334};
--
ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireFrontLeft"].vehicles["82oshkoshM911B_"] = {x=83,y=158,x2=104,y2=207};
ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireFrontRight"].vehicles["82oshkoshM911B_"] = {x=178,y=158,x2=198,y2=207};
--
ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireRearLeft"].vehicles["82oshkoshM911B_"] = {x=68,y=415,x2=213,y2=485};
ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles = ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["TireRearRight"].vehicles["82oshkoshM911B_"] = {x=68,y=485,x2=213,y2=555};
--
ISCarMechanicsOverlay.PartList["M911Trunk"] = {img="trunk", vehicles = {"82oshkoshM911B_"}};
ISCarMechanicsOverlay.PartList["M911Trunk"].vehicles = ISCarMechanicsOverlay.PartList["M911Trunk"].vehicles or {};
ISCarMechanicsOverlay.PartList["M911Trunk"].vehicles["82oshkoshM911B_"] = {x=77,y=237,x2=95,y2=298};
--
ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles = ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowFrontLeft"].vehicles["82oshkoshM911B_"] = {x=95,y=218,x2=108,y2=263};
ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles = ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowFrontRight"].vehicles["82oshkoshM911B_"] = {x=175,y=218,x2=188,y2=263};
ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles = ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowRearLeft"].vehicles["82oshkoshM911B_"] = {x=101,y=274,x2=115,y2=281};
ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles = ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindowRearRight"].vehicles["82oshkoshM911B_"] = {x=167,y=274,x2=181,y2=281};
--
ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles = ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles or {};
ISCarMechanicsOverlay.PartList["WindshieldRear"].vehicles["82oshkoshM911B_"] = {x=115,y=274,x2=167,y2=281};
ISCarMechanicsOverlay.PartList["Windshield"].vehicles = ISCarMechanicsOverlay.PartList["Windshield"].vehicles or {};
ISCarMechanicsOverlay.PartList["Windshield"].vehicles["82oshkoshM911B_"] = {x=108,y=208,x2=175,y2=218};
--
ISCarMechanicsOverlay.PartList["GasTank"].vehicles = ISCarMechanicsOverlay.PartList["GasTank"].vehicles or {};
ISCarMechanicsOverlay.PartList["GasTank"].vehicles["82oshkoshM911B_"] = {img="gastank", x=182,y=34,x2=269,y2=96};
--
end


Events.OnInitWorld.Add(info);
ContainerButtonIcons = ContainerButtonIcons or {}

local t = {}
t.trunk = getTexture("media/textures/trunk.png")
t.toolbox = getTexture("media/textures/toolbox.png")
t.spare = getTexture("media/textures/spare.png")

ContainerButtonIcons.M911Trunk = t.trunk
ContainerButtonIcons.M911Toolbox = t.toolbox
ContainerButtonIcons.M911SpareTire = t.spare

if not TowCarMod then TowCarMod = {} end
if not TowCarMod.Config then TowCarMod.Config = {} end

TowCarMod.Config.rigidTowVehicleWeight = 200

TowCarMod.Config.lowLevelAnimation = "RemoveGrass"
TowCarMod.Config.highLevelAnimation = "Loot"
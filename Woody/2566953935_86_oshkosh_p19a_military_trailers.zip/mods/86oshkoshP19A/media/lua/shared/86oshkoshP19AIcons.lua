ContainerButtonIcons = ContainerButtonIcons or {}

local t = {}
t.bigtrunkcomp = getTexture("media/textures/bigtrunkcomp.png")
t.small1comp = getTexture("media/textures/small1comp.png")
t.small2comp = getTexture("media/textures/small2comp.png")
t.small3comp = getTexture("media/textures/small3comp.png")

ContainerButtonIcons.P19ABigTrunkCompartment0 = t.bigtrunkcomp
ContainerButtonIcons.P19ASmallTrunkCompartment1 = t.small1comp
ContainerButtonIcons.P19ASmallTrunkCompartment2 = t.small2comp
ContainerButtonIcons.P19ASmallTrunkCompartment3 = t.small3comp

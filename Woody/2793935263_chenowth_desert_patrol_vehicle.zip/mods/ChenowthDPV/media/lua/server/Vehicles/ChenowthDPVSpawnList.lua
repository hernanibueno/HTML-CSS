if VehicleZoneDistribution then

    
    VehicleZoneDistribution.trafficjamw.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.trafficjamw.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 2};
    VehicleZoneDistribution.junkyard.chanceToPartDamage = 70;

    VehicleZoneDistribution.junkyard.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 5};
    VehicleZoneDistribution.junkyard.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 5};
    VehicleZoneDistribution.junkyard.chanceToPartDamage = 85;
    
    -- I really wish I could spawn these via events

    VehicleZoneDistribution.farm = VehicleZoneDistribution.farm or {}
    VehicleZoneDistribution.farm.vehicles = VehicleZoneDistribution.farm.vehicles or {}
    VehicleZoneDistribution.farm.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 3};
    VehicleZoneDistribution.farm.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 3};
    VehicleZoneDistribution.farm.spawnRate = 10;

    VehicleZoneDistribution.military = VehicleZoneDistribution.military or {}
    VehicleZoneDistribution.military.vehicles = VehicleZoneDistribution.military.vehicles or {}
    VehicleZoneDistribution.military.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 5};
    VehicleZoneDistribution.military.vehicles["Base.DesertPatrolVehicle"] = {index = -1, spawnChance = 5};
    VehicleZoneDistribution.military.spawnRate = 20;

end
-- this method was copied from the excellent Skateboard mod by Dislaik https://steamcommunity.com/sharedfiles/filedetails/?id=2728300240
-- require "Vehicles/ISUI/ISVehicleMenu"
-- require "Vehicles/TimedActions/ISStartVehicleEngine"

local function DesertPatrolVehicle_Enter(player)
	local vehicle = player:getVehicle()
	if not vehicle then return end
    local vehicleName = vehicle:getScriptName()
    local seat = vehicle:getSeat(player)
    if not seat then return end
	if seat == 1 and vehicleName:contains("Base.DesertPatrolVehicle") then		
		player:SetVariable("VehicleScriptName", "DesertPatrolVehicleLeft")
		return
	end
	if seat == 2 and vehicleName:contains("Base.DesertPatrolVehicle") then		
		player:SetVariable("VehicleScriptName", "DesertPatrolVehicleRight")
		return
	end
end

function DesertPatrolVehicle_Enter_Server(player)
	DesertPatrolVehicle_Enter(player)
end

local function DesertPatrolVehicle_Exit(player)
    sendClientCommand(player, "DesertPatrolVehicle", "PlayerExit", {})
    player:SetVariable("VehicleScriptName", "")
end

Events.OnEnterVehicle.Add(DesertPatrolVehicle_Enter)
Events.OnExitVehicle.Add(DesertPatrolVehicle_Exit)
Events.OnSwitchVehicleSeat.Add(DesertPatrolVehicle_Enter)
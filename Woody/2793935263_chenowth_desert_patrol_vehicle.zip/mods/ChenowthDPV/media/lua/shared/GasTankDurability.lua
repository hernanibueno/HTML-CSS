Events.OnPlayerUpdate.Add(function(player, vehicle, args, part)
    local vehicle = player.getVehicle and player:getVehicle() or nil
    if (vehicle and string.find( vehicle:getScriptName(), "DesertPatrolVehicle" )) then

vehicle:getPartById("GasTank"):setCondition(100)


end

end)
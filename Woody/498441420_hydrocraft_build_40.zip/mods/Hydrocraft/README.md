Hydrocraft Mod for Project Zomboid

Current Version: 11.1 - Tested on Build 40.43

Hydrocraft is a mod based around crafting and filling in the empty world of zomboid with more stuff. It is inspired by survival crafting games like Haven and Hearth. It is very much a WIP and will be tweaked and added onto.

Please report any issues or inconsistency that you find and share your suggestions!

You can report issues on the Hydrocraft Workshop page or right here on GitHub!

You can also visit the Hydrocraft page on TheIndieStone forum at http://theindiestone.com/forums/index.php/topic/11557-hydrocraft-mod/



--Randomized Books.
function HCRandombook(items, result, player)
    local book = ZombRand(191);	
    if book == 190 then
		player:getInventory():AddItem("Base.BookMechanic1");
    elseif book == 189 then	
		player:getInventory():AddItem("Base.BookMechanic2");
    elseif book == 188 then	
		player:getInventory():AddItem("Base.BookMechanic3");
    elseif book == 187 then	
		player:getInventory():AddItem("Base.BookMechanic4");
    elseif book == 186 then	
		player:getInventory():AddItem("Base.BookMechanic5");
    elseif book == 185 then		
		player:getInventory():AddItem("Base.BookMetalWelding1");
    elseif book == 184 then	
		player:getInventory():AddItem("Base.BookMetalWelding2");
    elseif book == 183 then	
		player:getInventory():AddItem("Base.BookMetalWelding3");
    elseif book == 182 then	
		player:getInventory():AddItem("Base.BookMetalWelding4");
    elseif book == 181 then	
		player:getInventory():AddItem("Base.BookMetalWelding5");
    elseif book == 180 then		
		player:getInventory():AddItem("Hydrocraft.HCBookcoalworking");
    elseif book == 179 then			
		player:getInventory():AddItem("Hydrocraft.HCBookjewelry");
    elseif book == 178 then		
		player:getInventory():AddItem("Hydrocraft.HCBookcomputerprograming");
    elseif book == 177 then		
		player:getInventory():AddItem("Hydrocraft.HCBookgemcutting");
    elseif book == 176 then		
		player:getInventory():AddItem("Hydrocraft.HCBookmetalurgy");
    elseif book == 175 then	
		player:getInventory():AddItem("Hydrocraft.HCBookalloys");
    elseif book == 174 then		
		player:getInventory():AddItem("Hydrocraft.HCBookbattery");
    elseif book == 173 then		
		player:getInventory():AddItem("Hydrocraft.HCBookwire");
    elseif book == 172 then	
		player:getInventory():AddItem("Hydrocraft.HCBookcryptozoology");
    elseif book == 171 then	
		player:getInventory():AddItem("Hydrocraft.HCBooktaxidermy");
    elseif book == 171 then	
		player:getInventory():AddItem("Hydrocraft.HCBooktitaniumworking");
    elseif book == 170 then		
		player:getInventory():AddItem("Hydrocraft.HCBookmycology");
    elseif book == 169 then		
		player:getInventory():AddItem("Hydrocraft.HCBookphotography");
    elseif book == 168 then	
		player:getInventory():AddItem("Hydrocraft.HCBooktailoring");
    elseif book == 167 then
		player:getInventory():AddItem("Hydrocraft.HCBookhatter");
    elseif book == 166 then
		player:getInventory():AddItem("Hydrocraft.HCBookcobbling");
    elseif book == 165 then
		player:getInventory():AddItem("Hydrocraft.HCBookarmorcrafting");
    elseif book == 164 then
		player:getInventory():AddItem("Hydrocraft.HCBookdistillery");
    elseif book == 163 then
		player:getInventory():AddItem("Base.BookCooking1");
    elseif book == 162 then
		player:getInventory():AddItem("Base.BookCooking2");
    elseif book == 161 then	
		player:getInventory():AddItem("Base.BookCooking3");
    elseif book == 160 then
		player:getInventory():AddItem("Base.BookCooking4");
    elseif book == 159 then
		player:getInventory():AddItem("Base.BookCooking5");
    elseif book == 158 then
		player:getInventory():AddItem("Base.BookCarpentry1");
    elseif book == 157 then
		player:getInventory():AddItem("Base.BookCarpentry2");
    elseif book == 156 then
		player:getInventory():AddItem("Base.BookCarpentry3");
    elseif book == 155 then
		player:getInventory():AddItem("Base.BookCarpentry3");
    elseif book == 154 then
		player:getInventory():AddItem("Base.BookCarpentry4");
    elseif book == 153 then
		player:getInventory():AddItem("Base.BookFarming5");
    elseif book == 152 then
		player:getInventory():AddItem("Base.BookFishing1");
    elseif book == 151 then
		player:getInventory():AddItem("Base.BookFishing2");
    elseif book == 150 then
		player:getInventory():AddItem("Base.BookFishing3");
    elseif book == 149 then	
		player:getInventory():AddItem("Base.BookFishing4");
    elseif book == 148 then
		player:getInventory():AddItem("Base.BookFishing5");
    elseif book == 147 then
		player:getInventory():AddItem("Base.BookTrapping1");
    elseif book == 146 then
		player:getInventory():AddItem("Base.BookTrapping2");
    elseif book == 145 then
		player:getInventory():AddItem("Base.BookTrapping3");
    elseif book == 144 then
		player:getInventory():AddItem("Base.BookTrapping4");
    elseif book == 143 then
		player:getInventory():AddItem("Base.BookTrapping5");
    elseif book == 142 then
		player:getInventory():AddItem("Base.BookFirstAid1");
    elseif book == 141 then
		player:getInventory():AddItem("Base.BookFirstAid2");
    elseif book == 140 then
		player:getInventory():AddItem("Base.BookFirstAid3");
    elseif book == 139 then
		player:getInventory():AddItem("Base.BookFirstAid4");
    elseif book == 138 then
		player:getInventory():AddItem("Base.BookFirstAid5");
    elseif book == 137 then
		player:getInventory():AddItem("Base.BookElectrician1");
    elseif book == 136 then
		player:getInventory():AddItem("Base.BookElectrician2");
    elseif book == 135 then
		player:getInventory():AddItem("Base.BookElectrician3");
    elseif book == 134 then
		player:getInventory():AddItem("Base.BookElectrician4");
    elseif book == 133 then
		player:getInventory():AddItem("Base.BookElectrician5");
    elseif book == 132 then
		player:getInventory():AddItem("Base.BookForaging1");
    elseif book == 131 then
		player:getInventory():AddItem("Base.BookForaging2");
    elseif book == 130 then
		player:getInventory():AddItem("Base.BookForaging3");
    elseif book == 129 then
		player:getInventory():AddItem("Base.BookForaging4");
    elseif book == 128 then
		player:getInventory():AddItem("Base.BookForaging5");
    elseif book == 127 then
		player:getInventory():AddItem("Hydrocraft.HCBookphone");
    elseif book == 126 then
		player:getInventory():AddItem("Hydrocraft.HCBookbiodiesel");
    elseif book == 126 then
		player:getInventory():AddItem("Hydrocraft.HCBookexplosives");
    elseif book == 125 then
		player:getInventory():AddItem("Hydrocraft.HCBooksoapmaking");
    elseif book == 124 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksailing");
    elseif book == 123 then
	    player:getInventory():AddItem("Hydrocraft.HCBookorganicchemistry");
    elseif book == 122 then
	    player:getInventory():AddItem("Hydrocraft.HCBookecology");
    elseif book == 121 then
	    player:getInventory():AddItem("Hydrocraft.HCBookradio");
    elseif book == 120 then
	    player:getInventory():AddItem("Hydrocraft.HCBookarcheology");
    elseif book == 119 then
	    player:getInventory():AddItem("Hydrocraft.HCBookcalligraphy");
    elseif book == 118 then	
	    player:getInventory():AddItem("Hydrocraft.HCBookastrology");
    elseif book == 117 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksculpting");
    elseif book == 116 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgardening");
    elseif book == 115 then
	    player:getInventory():AddItem("Hydrocraft.HCBookmicrobiology");
    elseif book == 114 then
	    player:getInventory():AddItem("Hydrocraft.HCBooklocksmithing");
    elseif book == 113 then
	    player:getInventory():AddItem("Hydrocraft.HCBookkoran");
    elseif book == 112 then
	    player:getInventory():AddItem("Hydrocraft.HCBookdutch");
    elseif book == 111 then
	    player:getInventory():AddItem("Hydrocraft.HCBookczech");
    elseif book == 110 then
	    player:getInventory():AddItem("Hydrocraft.HCBookegyptian");
    elseif book == 109 then
	    player:getInventory():AddItem("Hydrocraft.HCBookzulu");
    elseif book == 108 then
	    player:getInventory():AddItem("Hydrocraft.HCBookpolish");
    elseif book == 107 then
	    player:getInventory():AddItem("Hydrocraft.HCBookhebrew");
    elseif book == 106 then
	    player:getInventory():AddItem("Hydrocraft.HCBookfinnish");
    elseif book == 105 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgreek");
    elseif book == 104 then
	    player:getInventory():AddItem("Hydrocraft.HCBookarabic");
    elseif book == 103 then
	    player:getInventory():AddItem("Hydrocraft.HCBookhindi");
    elseif book == 102 then
	    player:getInventory():AddItem("Hydrocraft.HCBookportuguise");
    elseif book == 101 then
	    player:getInventory():AddItem("Hydrocraft.HCBookchinese");
    elseif book == 100 then	
	    player:getInventory():AddItem("Hydrocraft.HCBookjapanese");
    elseif book == 99 then
	    player:getInventory():AddItem("Hydrocraft.HCBookkorean");
    elseif book == 98 then
	    player:getInventory():AddItem("Hydrocraft.HCBookrussian");
    elseif book == 97 then
	    player:getInventory():AddItem("Hydrocraft.HCBookanarchist");
    elseif book == 96 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbicycle");
    elseif book == 95 then
	    player:getInventory():AddItem("Hydrocraft.HCBookjunk");
    elseif book == 94 then
	    player:getInventory():AddItem("Hydrocraft.HCBookrocketry");
    elseif book == 93 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgunsmithing");
    elseif book == 92 then
	    player:getInventory():AddItem("Hydrocraft.HCBookindustrial");
    elseif book == 91 then
	    player:getInventory():AddItem("Hydrocraft.HCBookmagnets");
    elseif book == 90 then
	    player:getInventory():AddItem("Hydrocraft.HCBookwelding");
    elseif book == 89 then
	    player:getInventory():AddItem("Hydrocraft.HCBookpharmacology");
    elseif book == 88 then
	    player:getInventory():AddItem("Hydrocraft.HCBookfungiguide");
    elseif book == 87 then
	    player:getInventory():AddItem("Hydrocraft.HCBookauto");
    elseif book == 86 then
	    player:getInventory():AddItem("Hydrocraft.HCBooktoys");
    elseif book == 85 then
	    player:getInventory():AddItem("Hydrocraft.HCBookpapermaking");
    elseif book == 84 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksericulture");
    elseif book == 83 then
	    player:getInventory():AddItem("Hydrocraft.HCBookherbalism");
    elseif book == 82 then
	    player:getInventory():AddItem("Hydrocraft.HCBookplastics");
    elseif book == 81 then
	    player:getInventory():AddItem("Hydrocraft.HCBookleatherworking");
    elseif book == 80 then
	    player:getInventory():AddItem("Hydrocraft.HCBookhunting");
    elseif book == 79 then
	    player:getInventory():AddItem("Hydrocraft.HCBookstoneworking");
    elseif book == 78 then
	    player:getInventory():AddItem("Hydrocraft.HCBookmasonry");
    elseif book == 77 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbasketry");
    elseif book == 76 then
	    player:getInventory():AddItem("Hydrocraft.HCBookcandlemaking");
    elseif book == 75 then
	    player:getInventory():AddItem("Hydrocraft.HCBookrubberworking");
    elseif book == 74 then
	    player:getInventory():AddItem("Hydrocraft.HCBooklithiumworking");
    elseif book == 73 then
	    player:getInventory():AddItem("Hydrocraft.HCBookaluminumworking");
    elseif book == 72 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgoldworking");
    elseif book == 71 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksilverworking");
    elseif book == 70 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksteelworking");
    elseif book == 69 then
	    player:getInventory():AddItem("Hydrocraft.HCBookleadworking");
    elseif book == 68 then
	    player:getInventory():AddItem("Hydrocraft.HCBookironworking");
    elseif book == 67 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbronzeworking");
    elseif book == 66 then
	    player:getInventory():AddItem("Hydrocraft.HCBooktinworking");
    elseif book == 65 then
	    player:getInventory():AddItem("Hydrocraft.HCBookcopperworking");
    elseif book == 64 then
	    player:getInventory():AddItem("Hydrocraft.HCBookglassworking");
    elseif book == 63 then	
	    player:getInventory():AddItem("Hydrocraft.HCBookpottery");
    elseif book == 62 then
	    player:getInventory():AddItem("Hydrocraft.HCBookarchery");
    elseif book == 61 then
	    player:getInventory():AddItem("Hydrocraft.HCBookanthropology");
    elseif book == 60 then
	    player:getInventory():AddItem("Hydrocraft.HCBookelectrical");
    elseif book == 59 then
	    player:getInventory():AddItem("Hydrocraft.HCBookplumbing");
    elseif book == 58 then
	    player:getInventory():AddItem("Hydrocraft.HCBookapiculture");
    elseif book == 57 then
	    player:getInventory():AddItem("Hydrocraft.HCBookamphibianguide");
    elseif book == 56 then
	    player:getInventory():AddItem("Hydrocraft.HCBookworldatlas");
    elseif book == 55 then
	    player:getInventory():AddItem("Hydrocraft.HCBooksociology");
    elseif book == 54 then
	    player:getInventory():AddItem("Hydrocraft.HCBookscience");
    elseif book == 53 then
	    player:getInventory():AddItem("Hydrocraft.HCBookrobotics");
    elseif book == 52 then
	    player:getInventory():AddItem("Hydrocraft.HCBookreptileguide");
    elseif book == 51 then
	    player:getInventory():AddItem("Hydrocraft.HCBookpoliticalscience");
    elseif book == 50 then
	    player:getInventory():AddItem("Hydrocraft.HCBookphysics");
    elseif book == 49 then
	    player:getInventory():AddItem("Hydrocraft.HCBookphilosophy");
    elseif book == 48 then
	    player:getInventory():AddItem("Hydrocraft.HCBookoceanography");
    elseif book == 47 then
	    player:getInventory():AddItem("Hydrocraft.HCBooknorsemyths");
    elseif book == 46 then
	    player:getInventory():AddItem("Hydrocraft.HCBookmammalguide");
    elseif book == 45 then
	    player:getInventory():AddItem("Hydrocraft.HCBookliterature");
    elseif book == 44 then
	    player:getInventory():AddItem("Hydrocraft.HCBooklaw");
    elseif book == 43 then
	    player:getInventory():AddItem("Hydrocraft.HCBookhealth");
    elseif book == 42 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgreekmyths");
    elseif book == 41 then
	    player:getInventory():AddItem("Hydrocraft.HCBookgeology");
    elseif book == 40 then
	    player:getInventory():AddItem("Hydrocraft.HCBookflowerguide");
    elseif book == 39 then
	    player:getInventory():AddItem("Hydrocraft.HCBookfishguide");
    elseif book == 38 then
	    player:getInventory():AddItem("Hydrocraft.HCBookeconomics");
    elseif book == 37 then
	    player:getInventory():AddItem("Hydrocraft.HCBookcommunications");
    elseif book == 36 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbiology");
    elseif book == 35 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbirdgude");
    elseif book == 34 then
	    player:getInventory():AddItem("Hydrocraft.HCBookbible");
    elseif book == 33 then
	    player:getInventory():AddItem("Hydrocraft.HCBookarthistory");
    elseif book == 32 then
	    player:getInventory():AddItem("Hydrocraft.HCBookanatomy");
    elseif book == 31 then
	    player:getInventory():AddItem("Hydrocraft.HCBookworldhistory");
    elseif book == 30 then
	    player:getInventory():AddItem("Hydrocraft.HCBookvet");
    elseif book == 29 then
	    player:getInventory():AddItem("Hydrocraft.HCBookstrigonometry");
    elseif book == 28 then
	    player:getInventory():AddItem("Hydrocraft.HCBooktreeguide");
    elseif book == 27 then
        player:getInventory():AddItem("Hydrocraft.HCBookthesaurus");
    elseif book == 26 then
        player:getInventory():AddItem("Hydrocraft.HCBookspanish");
    elseif book == 25 then
        player:getInventory():AddItem("Hydrocraft.HCBookscrap");
    elseif book == 24 then
        player:getInventory():AddItem("Hydrocraft.HCBookpoetry");
    elseif book == 23 then
        player:getInventory():AddItem("Hydrocraft.HCBookpaleontology");
    elseif book == 22 then
        player:getInventory():AddItem("Hydrocraft.HCBookmusic");
    elseif book == 21 then
        player:getInventory():AddItem("Hydrocraft.HCBookmedical");
    elseif book == 20 then
        player:getInventory():AddItem("Hydrocraft.HCBookmath");
    elseif book == 19 then
        player:getInventory():AddItem("Hydrocraft.HCBookitalian");
    elseif book == 18 then
        player:getInventory():AddItem("Hydrocraft.HCBookgerman");
    elseif book == 17 then
        player:getInventory():AddItem("Hydrocraft.HCBookgeometry");
    elseif book == 16 then
       player:getInventory():AddItem("Hydrocraft.HCBookgenealogy");
    elseif book == 15 then
        player:getInventory():AddItem("Hydrocraft.HCBookfrench");
    elseif book == 14 then
        player:getInventory():AddItem("Hydrocraft.HCBookfairytale");
    elseif book == 13 then
        player:getInventory():AddItem("Hydrocraft.HCBookentomology");
    elseif book == 12 then
        player:getInventory():AddItem("Hydrocraft.HCBookenglish");
    elseif book == 11 then
        player:getInventory():AddItem("Hydrocraft.HCBookencyclopedia");
    elseif book == 10 then
        player:getInventory():AddItem("Hydrocraft.HCBookdictionary");
    elseif book == 9 then
        player:getInventory():AddItem("Hydrocraft.HCBookboneworking");
    elseif book == 8 then
        player:getInventory():AddItem("Hydrocraft.HCBookchemistry");
    elseif book == 7 then
        player:getInventory():AddItem("Hydrocraft.HCBookceltic");
    elseif book == 6 then
        player:getInventory():AddItem("Hydrocraft.HCBookcalculus");
    elseif book == 5 then
        player:getInventory():AddItem("Hydrocraft.HCBookbedtime");
    elseif book == 4 then
        player:getInventory():AddItem("Hydrocraft.HCBookanimalhusbandry");
    elseif book == 3 then
       player:getInventory():AddItem("Hydrocraft.HCBookamericanhistory");
    elseif book == 2 then
        player:getInventory():AddItem("Hydrocraft.HCBookalmanac");
    elseif book == 1 then
       player:getInventory():AddItem("Hydrocraft.HCBookastronomy");   
    elseif book == 0 then
       player:getInventory():AddItem("Hydrocraft.HCBookalgebra");      
    end
end

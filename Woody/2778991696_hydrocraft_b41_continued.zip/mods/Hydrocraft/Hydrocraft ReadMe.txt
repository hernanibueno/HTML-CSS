Hydrocraft Build 41 Continued(Use at your OWN RISK!)

Credits

Coders - arrukus, BrokenMnemonic, Daantje, DemolitionDerby, Flamester, Hydromancerx, IanSchot, JackMods, Man_In_The_Purple_Hat, Minnigin, MisterInSayne, New Wise Man, UngratefulDead, Yossitaru, YuriNikolai, Hasilein, Hugo_Qwerty, Robotex140

Artists - Atoxwarrior, Batura, billwa, Crowborn, Cyrrent Eiledoll, DeadlyStr1ke, Filthy Mollie, fluffe9911, Fuji, Hydromancerx, IanSchot, Kaltag, Kittysong, Leliana, Man_In_The_Purple_Hat, Minnigin, New Wise Man, Nitengal, ORMtnMan, Rampage132003, Rhodix, Scyoni, Sparrow, StalkerCZ, Svarog, UngratefulDead, WolfeClaw, YuriNikolai, Zombadger

Included Parts from the following Mods
- Advanced Trading Post Mod By Nolan
- Armor Mod By Nolan at Aggressive Gaming
- Batura's Icons By Batura
- Breaking Dead By Cyrrent Eiledoll
- Car Wreckage By dko112
- CCCP By MickyPain
- Chansaw Mod By Nolan at Aggressive Gaming
- Christmas Food By Rodjah
- Cigarette Pack By lifemare
- Compass Mod by ethanwdp
- Craftable Axes By Tooks
- Drip Irrigration Mod By Kyun, Bindcoder, Drauka and Damntry (Whole Mod)
- Engless Sprites By Jatta Pake
- Extra Weapons Mod By tommysticks
- Farmoid Mod by Kurongo
- FlourCraft Mod By Dudeman325
- Foods and Spices Mod By kinyoshi
- Fur Clothes Mod By Dudeman325
- Homemade Bats and Clubs by Dudeman325
- Horses Mod By Leliana
- Hunting Mod By UngratefulDead
- Hydrocraft 3D Weapons By francogp
- Improvised ContainersBy WolfeClaw
- Juices By Basseri
- Littering Mod By Svarog
- Lock Crafting Mod By Nolan at Aggressive Gaming
- Meat Curing Mod By ZimTown
- More Edibles By Svarog
- Not Enough Bags By RoboMat
- Player Traps Mod By Nolan at Aggressive Gaming
- Potato Cannon By Proxy_Codex
- Random Sprites By Svarog
- Recycling By Ramibuk
- Safe Storage Mod By Nolan at Aggressive Gaming
- Self Inflictable Injuries By Nolan at Aggressive Gaming
- Taxi Mod By Terminus PZ Server
- Umbrella Mod By Suomiboi
- Wedge's Hydrocraft TWeaks
- Wooden Stakes By Nightsinger

Translations
- Chinese - By Sky_Orc_Mm
- French - By Klare, Darkweeeeeeeed, Kitsune Alias Nana
- Italian - By Woldren
- Korean - By DocJason
- Russian - By Humort, KChernysh, Nebula, vSterlin
- Spanish - By francogp, EUDOXIO, Raiben
- Turkish - By DemirHerif

Artists from Icon Archive
- Brown (Eiichi Ueki)
- cuberto
- Etherbrian
- Fatcow Web Hosting
- Icons-Land
- Iconshock
- Ilicon
- I-MIL
- IronDevil
- Jacqueline Simon
- Meramera
- Mozco
- Pixture
- Zapato

Artists from Deviant Art
- Dajikun
- Henrique Lazarini

Artists from Open Game Art
- yd

Artists from PixelJoint
- stickfigureman3

Artists from Yoyo Games
- Fin (Donated by Hicks)

Other Artists
- Cartoonize My Pet
- The Spriters Resource

Sounds from ZapSplat
require "NPCs/ZombiesZoneDefinition"



table.insert(ZombiesZoneDefinition.SecretBase,{name = "HazardSuit", chance=0.5});
table.insert(ZombiesZoneDefinition.Default,{name = "HazardSuit", chance=0.01});


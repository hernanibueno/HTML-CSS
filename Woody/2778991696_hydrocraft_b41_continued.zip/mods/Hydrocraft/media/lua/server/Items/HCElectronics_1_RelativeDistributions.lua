---------------------------------------------------------
--- 2021-12-27 by lorgalis
---------------------------------------------------------
function HCelectools(m)
        retVal =
        {
                "Hydrocraft.HCSolder",              m*10,
                "Hydrocraft.HCSoldergun",           m*1,
                "Hydrocraft.HCSoldergundead",       m*1,
                "Hydrocraft.HCTerminalstrip",       m*5,
                "Hydrocraft.HCCablecopper",         m*5,
                "Hydrocraft.HCColoredwire",         m*5,
        };
        return retVal
end

function HCeleccomputer(m)
        retVal =
        {
                "Hydrocraft.HCCPU",                 m*1,
                "Hydrocraft.HCComputer",            m*1,
                "Hydrocraft.HCComputerPSU",         m*1,
                "Hydrocraft.HCComputerfan",         m*1,
                "Hydrocraft.HCComputerkeyboard",    m*1,
                "Hydrocraft.HCComputermonitor",     m*1,
                "Hydrocraft.HCComputermouse",       m*1,
                "Hydrocraft.HCJoystick",            m*1,
                "Hydrocraft.HCMousepad",            m*1,
                "Hydrocraft.HCPrinter",             m*1,
                "Hydrocraft.HCRouter",              m*1,
                "Hydrocraft.HCScaner",              m*1,
                "Hydrocraft.HCPowercord",           m*1,
        };
        return retVal
end

function HCeleccord(m)
        retVal =
        {
                "Hydrocraft.HCPowercord",           m*1,
        };
        return retVal
end

function HCelecoffice(m)
        retVal =
        {
                "Hydrocraft.HCCopymachine",         m*1,
                "Hydrocraft.HCFaxmachine",          m*1,
        };
        return retVal
end

function HCelecmachines(m)
        retVal =
        {
                "Hydrocraft.HCCalculator",          m*1,
                "Hydrocraft.HCCashregister",        m*1,
                "Hydrocraft.HCElectonicscale",      m*1,
        };
        return retVal
end

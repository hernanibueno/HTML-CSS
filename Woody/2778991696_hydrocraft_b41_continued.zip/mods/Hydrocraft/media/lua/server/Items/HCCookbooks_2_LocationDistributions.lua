------------------------------------------------------------ 
-- Adds relative distributions to the  different locations
-- created 2021-12-27 by fetisch
------------------------------------------------------------

require "Items/ProceduralDistributions";

require "HCDistributionFunctions";

-- insertItemListsInProcDistribution( "MedicalStorageTools",    		{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "LibraryBooks",    		{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "LibraryCounter",    	{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "BookstoreBooks",    	{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "LivingRoomShelf",    	{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "PostOfficeBooks",    	{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "CrateBooks",    		{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "KitchenBook",    		{ HCcookbooks(1)} );
insertItemListsInProcDistribution( "BakeryMisc",    		{ HCcookbooks(0.3)} );





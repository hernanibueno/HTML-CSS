---------------------------------------------------------
--- 2021-12-30 by fetisch
---------------------------------------------------------
function HCfoodbar(m)
        retVal =
        {
         "Hydrocraft.HCWhiskey1",  m*1,
         "Hydrocraft.HCWhiskey2",  m*1,
         "Hydrocraft.HCWhiskey3",  m*1,
         "Hydrocraft.HCWhiskey4",  m*1,
         "Hydrocraft.HCWhiskeycorn",  m*1,
-- "Hydrocraft.HCWhiskeyeggnogbottle ",  m*0,
-- "Hydrocraft.HCWhiskeycolademonobottle ",  m*0,
         "Hydrocraft.HCBourbon1",  m*1,
         "Hydrocraft.HCBourbon2",  m*1,
         "Hydrocraft.HCScotch1",  m*1,
         "Hydrocraft.HCRum1",  m*1,
         "Hydrocraft.HCGin1",  m*1,
         "Hydrocraft.HCGin2",  m*1,
         "Hydrocraft.HCGin3",  m*1,
         "Hydrocraft.HCVodka1",  m*1,
         "Hydrocraft.HCVodka2",  m*1,
         "Hydrocraft.HCBitters",  m*1,
         "Hydrocraft.HCTriplesec",  m*1,
         "Hydrocraft.HCVermouth",  m*1,
         "Hydrocraft.HCAbsinth",  m*1,
         "Hydrocraft.HCHerballiqueur",  m*1,
         "Hydrocraft.HCTequila",  m*1,
         "Hydrocraft.HCMezcal",  m*1,
-- "Hydrocraft.HCMezcalemptyworm",  m*0,
-- "Hydrocraft.HCMezcalworm",  m*0,
-- "Hydrocraft.HCDrinkoldfashioned",  m*0,
-- "Hydrocraft.HCDrinkmartini",  m*0,
-- "Hydrocraft.HCDrinkmanhattan",  m*0,
-- "Hydrocraft.HCDrinkdaquiri",  m*0,
-- "Hydrocraft.HCDrinkbloodymary",  m*0,
-- "Hydrocraft.HCDrinkwhiskeysour",  m*0,
-- "Hydrocraft.HCDrinkmaitai",  m*0,
-- "Hydrocraft.HCDrinkcosmo",  m*0,
-- "Hydrocraft.HCDrinktomcollins",  m*0,
-- "Hydrocraft.HCDrinklongisland",  m*0,
-- "Hydrocraft.HCDrinkgimlet",  m*0,
-- "Hydrocraft.HCDrinkplanterspunch",  m*0,
-- "Hydrocraft.HCDrinkwhiskeyandcoke",  m*0,
-- "Hydrocraft.HCDrinkmargarita",  m*0,
-- "Hydrocraft.HCSake",  m*0,
   "Hydrocraft.HCApplejack",  m*1,
   "Hydrocraft.HCPeachschnapps",  m*1,
   "Hydrocraft.HCFlip",  m*1,
-- "Hydrocraft.HCAguaardiente ",  m*0,
-- "Hydrocraft.HCEggnogpot ",  m*0,
-- "Hydrocraft.HCEggnogmug ",  m*0,
-- "Hydrocraft.HCColademonopot ",  m*0,
-- "Hydrocraft.HCColademonomug ",  m*0,
--- Distillery.txt:
-- Result:HCApplejack=20,
-- Result:HCFlip=20,
-- Result:HCGin3=20,
-- Result:HCMezcal=20,
-- Result:HCPeachschnapps=20,
-- Result:HCTequila=20,
-- Result:HCVodka=20,
-- Result:HCWhiskeycorn=20,
-- Result:WhiskeyFull=20,


        };
        return retVal
end

function HCfoodbarbeer(m)
        retVal =
        {
         "Hydrocraft.HCBeer1",  m*1,
         "Hydrocraft.HCBeer2",  m*1,
         "Hydrocraft.HCBeer3",  m*1,
         "Hydrocraft.HCBeer4",  m*1,
         "Hydrocraft.HCBeer5",  m*1,
         "Hydrocraft.HCBeer6",  m*1,
         "Hydrocraft.HCBeer7",  m*1,
         "Hydrocraft.HCBeer8",  m*1,
         "Hydrocraft.HCBeercan1",  m*1,
         "Hydrocraft.HCBeercan2",  m*1,
         "Hydrocraft.HCBeercan3",  m*1,
         "Hydrocraft.HCBeercan4",  m*1,
         "Hydrocraft.HCBeercan5",  m*1,
         "Hydrocraft.HCBeercan6",  m*1,
         "Hydrocraft.HCBeercan7",  m*1,
         "Hydrocraft.HCBeercan8",  m*1,
         "Hydrocraft.HCBeercan9",  m*1,
         "Hydrocraft.HCBeercan10",  m*1,
         "Hydrocraft.HCMead",  m*1,
         "Hydrocraft.HCMead2",  m*1,
        };
        return retVal
end

function HCfoodbarbeerpack(m)
        retVal =
        {
         "Hydrocraft.HCBeercan1pack",  m*1,
         "Hydrocraft.HCBeercan2pack",  m*1,
         "Hydrocraft.HCBeercan3pack",  m*1,
         "Hydrocraft.HCBeercan4pack",  m*1,
         "Hydrocraft.HCBeercan5pack",  m*1,
         "Hydrocraft.HCBeercan6pack",  m*1,
         "Hydrocraft.HCBeercan7pack",  m*1,
         "Hydrocraft.HCBeercan8pack",  m*1,
         "Hydrocraft.HCBeercan9pack",  m*1,
         "Hydrocraft.HCBeercan10pack",  m*1,
        };
        return retVal
end


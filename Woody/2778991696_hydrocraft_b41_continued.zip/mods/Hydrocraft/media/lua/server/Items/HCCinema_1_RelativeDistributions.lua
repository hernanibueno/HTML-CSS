---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function HCcinema(m)
        retVal =
        {
                "Hydrocraft.HC3Dglasses",       m*1,
                "Hydrocraft.HCCinematicket",    m*2,
                "Hydrocraft.HCFilmcan",         m*1,
                "Hydrocraft.HCMovieroll",       m*1,
                "Hydrocraft.HCProjector",       m*1,
        };
        return retVal
end

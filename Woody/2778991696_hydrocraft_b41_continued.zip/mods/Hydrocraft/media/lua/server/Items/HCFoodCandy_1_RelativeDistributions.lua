---------------------------------------------------------
--- 2021-12-27 by fetisch
--- @todo gums as new function
---------------------------------------------------------
function HCfoodcandy(m)
        retVal =
        {
-- "Hydrocraft.HCChocolateshavings",  m*0,
			"Hydrocraft.HCChocolatewhite",  m*1,
			"Hydrocraft.HCChocolatedark",  m*1,
			"Hydrocraft.HCTrailmix",  m*1,
			"Hydrocraft.HCEnergybar	",  m*1,
			"Hydrocraft.HCGum",  m*1,
-- "Hydrocraft.HCGumstick",  m*0,
			"Hydrocraft.HCGum2",  m*1,
-- "Hydrocraft.HCGumstick2",  m*0,
			"Hydrocraft.HCGum3",  m*1,
-- "Hydrocraft.HCGumstick3",  m*0,
			"Hydrocraft.HCCandycorn",  m*2,
			"Hydrocraft.HCCandymnm",  m*1,
			"Hydrocraft.HCCandyrainbow",  m*1,
			"Hydrocraft.HCGummybears",  m*1,
			"Hydrocraft.HCGummyworms",  m*1,
			"Hydrocraft.HCJellybeans",  m*1,
			"Hydrocraft.HCTaffy",  m*1,
			"Hydrocraft.HCCandycherry",  m*1,
			"Hydrocraft.HCCandyapple",  m*1,
-- "Hydrocraft.HCCandymixed",  m*0,
			"Hydrocraft.HCFruitleather",  m*1,
        };
        return retVal
end


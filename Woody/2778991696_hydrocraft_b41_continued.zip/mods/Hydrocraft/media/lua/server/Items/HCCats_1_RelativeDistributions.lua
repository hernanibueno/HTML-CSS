---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function cats(m)
        retVal =
        {
                "Hydrocraft.HCCatblackfemale",  m*1,
                "Hydrocraft.HCCatblackmale",    m*1,
                "Hydrocraft.HCCatbluefemale",   m*1,
                "Hydrocraft.HCCatbluemale",     m*1,
                "Hydrocraft.HCCatbrownfemale",  m*1,
                "Hydrocraft.HCCatbrownmale",    m*1,
                "Hydrocraft.HCCatcreamfemale",  m*1,
                "Hydrocraft.HCCatcreammale",    m*1,
                "Hydrocraft.HCCatfemale",       m*1,
                "Hydrocraft.HCCatgingerfemale", m*1,
                "Hydrocraft.HCCatgingermale",   m*1,
                "Hydrocraft.HCCatmale",         m*1,
                "Hydrocraft.HCCatsilverfemale", m*1,
                "Hydrocraft.HCCatsilvermale",   m*1,
                "Hydrocraft.HCCatwhitefemale",  m*1,
                "Hydrocraft.HCCatwhitemale",    m*1,
                "Hydrocraft.HCCatpoop",         m*2,
        };
        return retVal
end
                
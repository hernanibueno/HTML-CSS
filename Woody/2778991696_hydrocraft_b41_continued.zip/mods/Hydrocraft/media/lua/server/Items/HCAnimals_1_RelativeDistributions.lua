---------------------------------------------------------
--- Dead Animals that could be found in butchershops  
--- 2021-12-22 by fetisch
---------------------------------------------------------
function butcheranimals(m)
        retVal =
        {
                "Hydrocraft.HCCowdead",         m*1,
                "Hydrocraft.HCCowdead2",        m*1,
                "Hydrocraft.HCGoatdead",        m*4,
                "Hydrocraft.HCGoatdead2",       m*4,
                "Hydrocraft.HCPigdead",         m*5,
                "Hydrocraft.HCPigeondead",      m*2,
                "Hydrocraft.HCSheepdead",       m*4,     
        };
        return retVal
end

function butcherduck(m)
        retVal =
        {
                "Hydrocraft.HCDuckdead",        m*4,
        };
        return retVal
end

function butcherchicken(m)
        retVal =
        {
                "Hydrocraft.HCChickendead",     m*10,
                "Hydrocraft.HCChickendead2",    m*10,
        };
        return retVal
end


---------------------------------------------------------
--- 2021-12-26 by lorgalis
---------------------------------------------------------
function HCchemistry(m)
        retVal =
        {
                "Hydrocraft.HCSolidfuelbox",                   m*2,
                "Hydrocraft.HCNitricacid",                     m*2,
                "Hydrocraft.HCChemicalbottlesodiumhydroxide",  m*1,
                "Hydrocraft.HCKAS",                            m*1,
        };
        return retVal
end

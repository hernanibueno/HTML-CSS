---------------------------------------------------------
--- 2021-12-27 by fetisch
---------------------------------------------------------
function HCbreakfast(m)
        retVal =
        {
			"Hydrocraft.HCCereal2",  m*1,
			"Hydrocraft.HCCereal3",  m*1,
-- "Hydrocraft.HCBowlofcereal",  m*0,
-- "Hydrocraft.HCFriedegg",  m*0,
-- "Hydrocraft.HCScrambledegg",  m*0,
-- "Hydrocraft.HCScrambledeggcheese",  m*0,
-- "Hydrocraft.HCOmelet",  m*0,
-- "Hydrocraft.HCOmeletveg",  m*0,
-- "Hydrocraft.HCHardboiledegg",  m*0,
        };
        return retVal
end


------------------------------------------------------------ 
-- Adds relative distributions to the  different locations
-- created 2021-12-27 by fetisch
------------------------------------------------------------

require "Items/ProceduralDistributions";

require "HCDistributionFunctions";

-- insertItemListsInProcDistribution( "BinBar",    			{ bugs(1), spider(1) } );
insertItemListsInProcDistribution( "BinBar",    		{ bugs(1), spider(1) } );
insertItemListsInProcDistribution( "BinGeneric",    	{ bugs(1), spider(1) } );
insertItemListsInProcDistribution( "CrateRandomJunk",	{ bugs(1), spider(1) } );


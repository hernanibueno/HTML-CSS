if VehicleZoneDistribution then

VehicleZoneDistribution.parkingstall.vehicles["Base.k153"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.medium.vehicles["Base.k153"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.good.vehicles["Base.k153"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.military.vehicles["Base.k153"] = {index = -1, spawnChance = 20};
VehicleZoneDistribution.ranger.vehicles["Base.k153"] = {index = -1, spawnChance = 5};
VehicleZoneDistribution.trailerpark.vehicles["Base.k153"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjams.vehicles["Base.k153"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.k153"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.parkingstall.vehicles["Base.k153police"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.medium.vehicles["Base.k153police"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.good.vehicles["Base.k153police"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.police.vehicles["Base.k153police"] = {index = -1, spawnChance = 20};
VehicleZoneDistribution.trailerpark.vehicles["Base.k153police"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.ranger.vehicles["Base.k153police"] = {index = -1, spawnChance = 5};
VehicleZoneDistribution.trafficjams.vehicles["Base.k153police"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.k153police"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.parkingstall.vehicles["Base.k153turret"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.medium.vehicles["Base.k153turret"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.good.vehicles["Base.k153turret"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.military.vehicles["Base.k153turret"] = {index = -1, spawnChance = 20};
VehicleZoneDistribution.ranger.vehicles["Base.k153turret"] = {index = -1, spawnChance = 5};
VehicleZoneDistribution.trailerpark.vehicles["Base.k153turret"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjams.vehicles["Base.k153turret"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.k153turret"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.parkingstall.vehicles["Base.k153emer"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.medium.vehicles["Base.k153emer"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.good.vehicles["Base.k153emer"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.fire.vehicles["Base.k153emer"] = {index = -1, spawnChance = 20};
VehicleZoneDistribution.ambulance.vehicles["Base.k153emer"] = {index = -1, spawnChance = 20};
VehicleZoneDistribution.trailerpark.vehicles["Base.k153emer"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjams.vehicles["Base.k153emer"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.k153emer"] = {index = -1, spawnChance = 2};

end